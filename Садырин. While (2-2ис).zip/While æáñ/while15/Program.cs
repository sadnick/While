﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace while15
{
    class Program
    {
        /// <summary>
        /// Начальный вклад в банке равен 1000 руб. В конце каждого месяца размер вклада увеличивается на P процентов от имеющейся суммы (P — вещественное число, 0 < P < 25)
        /// По данному P определить, через сколько месяцев размер вклада превысит 1100 руб., и вывести найденное количество месяцев K (целое число) и итоговый размер вклада S (вещественное число).
        /// </summary>

        static void Main(string[] args)
        {
            
            Console.Write("Введите процент ежемесечного увеличения вклада(от 0 до 25): ");
            double p = double.Parse(Console.ReadLine());
            double S;
            S = 1000;
            int k;
            k = 0;
            while (S <= 1100)
            {
                S = (S / 100 * p) + S;
                ++k;
            }
            Console.WriteLine("Размер вклада превысит 1100 руб. через {0}месяц(а)(ев) и станет равным {1:F2} руб.", k, S);
            Console.ReadKey();
        }
    }
}
