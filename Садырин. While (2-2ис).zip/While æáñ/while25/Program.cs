﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace while25
{
    class Program
    {
        /// <summary>
        /// Дано целое число N (> 1). Найти первое число Фибоначчи, большее N (определение чисел Фибоначчи дано в задании While24).
        /// </summary>

        static void Main(string[] args)
        {
             Console.WriteLine("Дано целое число N (> 1). Найти первое число Фибоначчи, большее N");
            Console.Write("Введите N: ");
            int n = int.Parse(Console.ReadLine());
            int a = 1;//Первое число ряда Фибоначчи. 
            int b = 1;// второе число Фиббоначчи
            while (n >= b)
            {
                int tmp = b;// записываем второе число во временную переменную
                b = a + b;// записываем вместо второго числа, следующее число Фиббоначчи
                a = tmp;// переносим значение второго числа в первое
            }
            Console.WriteLine("Первое число Фибоначчи = {0}", b);
            Console.ReadKey();
        }
    }
}
