﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace while23
{
    class Program
    {
        /// <summary>
        ///  Даны целые положительные числа A и B. Найти их наибольший общий делитель (НОД), используя алгоритм Евклида:
        ///НОД(A, B) = НОД(B, A mod B),    если B ≠ 0; НОД(A, 0) = A,
        ///где «mod» обозначает операцию взятия остатка от деления.
        /// </summary>

        static void Main(string[] args)
        {
            Console.Write("a= ");
            int a = int.Parse(Console.ReadLine());
            Console.Write("b= ");
            int b = int.Parse(Console.ReadLine());
            while ((a != 0) && (b != 0)) 
            {
                if (a >= b) 
                {
                    a = a % b;
                }
                else b = b % a;
            }
            Console.WriteLine("{0}", a + b);
            Console.ReadKey();
        }
    }
}
