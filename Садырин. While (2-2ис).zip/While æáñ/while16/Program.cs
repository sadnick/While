﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace while16
{
    
    class Program
    {
        /// <summary>
        /// Спортсмен-лыжник начал тренировки, пробежав в первый день 10 км. Каждый следующий день он увеличивал длину пробега на P процентов от пробега предыдущего дня (P — вещественное, 0 < P < 50). 
        /// По данному P определить, после какого дня суммарный пробег лыжника за все дни превысит 200 км, и вывести найденное количество дней K (целое) и суммарный пробег S (вещественное число).
        /// </summary>

        static void Main(string[] args)
        {
            Console.Write("Введите процент ежедневного увеличения длины пробега(от 0 до 50): ");
            int p = int.Parse(Console.ReadLine());
            double S;
            S = 10;
            int k;
            k = 1;
            while (S <= 200)
            {
                S = (S / 100 * p) + S;
                ++k;
            }
            Console.WriteLine("Размер длины пробега превысит 200 км через {0}месяц(а)(ев) и станет равным {1:F2} км.", k, S);
            Console.ReadKey();
        }
    }
}
