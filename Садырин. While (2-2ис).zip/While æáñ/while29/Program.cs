﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace while29
{
    class Program
    {
        /// <summary>
        /// Дано вещественное число ε (> 0). Последовательность вещественных чисел AK определяется следующим образом:
        ///A1 = 1,        A2 = 2,        AK = (AK−2 + 2·AK−1)/3,    K = 3, 4, … .
        ///Найти первый из номеров K, для которых выполняется условие |AK − AK−1| < ε, и вывести этот номер, а также числа AK−1 и AK.
        /// </summary>

        static void Main(string[] args)
        {

        }
    }
}
