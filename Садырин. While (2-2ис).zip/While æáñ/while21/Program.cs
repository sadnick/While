﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace while21
{
    class Program
    {
        /// <summary>
        /// Дано целое число N (> 0). С помощью операций деления нацело и взятия остатка от деления определить, имеются ли в записи числа N нечетные цифры. 
        /// Если имеются, то вывести true, если нет — вывести false.
        /// </summary>

        static void Main(string[] args)
        {
            Console.Write("Введите число N, которое больше 0: ");
            int n = int.Parse(Console.ReadLine());
            bool pr;
            pr = false;
            while ((n > 0) && (pr == false))
            {
                if (n % 2 == 0)
                {
                    n = n / 10;
                }
                else pr = true;
            }
            Console.WriteLine("{0}", pr);
            Console.ReadKey();
        }
    }
}
