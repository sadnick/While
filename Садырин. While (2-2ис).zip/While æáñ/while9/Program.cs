﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace while9
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Дано целое число N (> 1). Найти наименьшее целое число K, при котором выполняется неравенство 3^K > N.");
            Console.Write("Введите целое число N, где N>1: ");
            int n = int.Parse(Console.ReadLine());
            int k;
            k = 0;
            while (Math.Pow(3, k) <= n)
            {
                ++k;
            }
            Console.WriteLine("Наименьшее целое K = {0}", k);
            Console.ReadKey();
        }
    }
}
