﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace while5
{
    class Program
    {
        static void Main(string[] args)
        {
            int n, k;
            Console.WriteLine("Дано целое число N (> 0), являющееся некоторой степенью числа 2: N = 2K. Найти целое число K — показатель этой степени.");
            Console.Write("Введите число N: ");
            n = int.Parse(Console.ReadLine());
            k = 0;
            while (n > 1) 
            {
                n = n / 2;
                ++k;
            }
            Console.Write("K = {0}", k);
            Console.ReadKey();
        }
    }
}
