﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace while4
{
    class Program
    {
        static void Main(string[] args)
        {
            int a;
            Console.WriteLine("Дано целое число N (> 0). Если оно является степенью числа 3, то вывести true, если не является — вывести false.");
            Console.Write("Введите число, которое больше 0: ");
            a = int.Parse(Console.ReadLine());
            while (a % 3 == 0)
            {
                a = a / 3;
            }
            if (a == 1)
            {
                Console.WriteLine("true");
            }
            else Console.WriteLine("false");
            Console.ReadKey();
        }
    }
}
