﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace while22
{
    class Program
    {
        /// <summary>
        ///  Дано целое число N (> 1). Если оно является простым, т. е. не имеет положительных делителей, кроме 1 и самого себя, то вывести true, иначе вывести false.
        /// </summary>

        static void Main(string[] args)
        {
            Console.WriteLine("Дано целое число N(> 1). Если оно является простым, т. е.не имеет положительных делителей, кроме 1 и самого себя, то вывести true, иначе вывести false.");
            Console.Write("Введите число N, которое больше 1: ");
            int n = int.Parse(Console.ReadLine());
            bool pr;
            pr = true;
            int s;
            s = 2;
            while ((s != n) && (pr == true))
            {
                if (n % s != 0)
                {
                    ++s;
                }
                else pr = false;
            }
            Console.WriteLine("{0}", pr);
            Console.ReadKey();
        }
    }
}
