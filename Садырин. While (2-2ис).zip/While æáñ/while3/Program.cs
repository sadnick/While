﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace while3
{
    class Program
    {
        static void Main(string[] args)
        {
            int n, k, temp, num;
            Console.WriteLine("Даны целые положительные числа N и K. Используя только операции сложения и вычитания, найти частное от деления нацело N на K, а также остаток от этого деления.");
            Console.Write("Введите N: ");
            n = int.Parse(Console.ReadLine());                    
            Console.Write("Введите K: ");
            k = int.Parse(Console.ReadLine());
            // Основная программа
            temp = n;
            num = -1;
            while (temp >= 0) 
            {
                temp = temp - k;
                ++num;
            }
            Console.WriteLine("Результат деления нацело: {0}", num);
            Console.WriteLine("Остаток от деления: {0}", temp + k);
            Console.ReadKey();
        }
    }
}
