﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace while7
{
    class Program
    {
        static void Main(string[] args)
        {
            int n, k;
            Console.WriteLine("Дано целое число N (> 0). Найти наименьшее целое положительное число K, квадрат которого превосходит N: K2 > N. Функцию извлечения квадратного корня не использовать.");
            Console.Write("Введите целое положительное число: ");
            n = int.Parse(Console.ReadLine());
            k = 1;
            while (k * k <= n) 
            {
                ++k;
            }
            Console.WriteLine("Ответ: {0}", k);
            Console.ReadKey();
        }
    }
}
