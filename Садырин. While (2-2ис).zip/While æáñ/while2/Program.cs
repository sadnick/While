﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace while2
{
    class Program
    {
        static void Main(string[] args)
        {
            double a, b, temp;
            int num;
            Console.WriteLine("Даны положительные числа A и B (A > B). На отрезке длины A размещено максимально возможное количество отрезков длины B (без наложений)." +
                " Не используя операции умножения и деления, найти количество отрезков B, размещенных на отрезке A.");
            // Ввод данных
            #region
            Console.WriteLine("Введите положительные числа A и B (A > B): ");
            Console.Write("Введите A: ");
            a = double.Parse(Console.ReadLine());
            Console.Write("Введите B: ");
            b = double.Parse(Console.ReadLine());
            #endregion
            // Основная программа
            temp = a;
            num = -1;
            while (temp >= 0) 
            {
                temp = temp - b;
                ++num;
            }
            Console.WriteLine("Количество отрезков B размещенных на A = {0}", num);
            Console.ReadKey();
        }
    }
}
