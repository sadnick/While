﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace While1
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Даны положительные числа A и B (A > B). На отрезке длины A размещено максимально возможное количество отрезков длины B (без наложений)." +
               " Не используя операции умножения и деления, найти длину незанятой части отрезка A.");
            double A, b;
            
            #region
            Console.WriteLine("Введите положительные числа A и B, где A>B:");
            Console.Write("Введите A: ");
            A = double.Parse(Console.ReadLine());
            Console.Write("Введите B: ");
            b = double.Parse(Console.ReadLine());
            #endregion
            while (A >= b) 
            {
                A = A - b;
                Console.WriteLine("Длина незанятой части отрезка A: {0}", A);
            }
            Console.ReadKey();
        }
    }
}
