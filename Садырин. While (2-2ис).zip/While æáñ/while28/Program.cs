﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace while28
{
    class Program
    {
        /// <summary>
        /// Дано вещественное число ε (> 0). Последовательность вещественных чисел AK определяется следующим образом:
        ///A1 = 2,        AK = 2 + 1/AK−1,    K = 2, 3, … .
        ///Найти первый из номеров K, для которых выполняется условие |AK − AK−1| < ε, и вывести этот номер, а также числа AK−1 и AK.
        /// </summary>

        static void Main(string[] args)
        {

        }
    }
}
